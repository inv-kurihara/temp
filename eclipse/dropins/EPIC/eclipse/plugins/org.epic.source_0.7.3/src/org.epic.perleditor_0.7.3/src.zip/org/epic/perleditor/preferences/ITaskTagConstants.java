package org.epic.perleditor.preferences;

/**
 * @author philipp
 *
 */
public interface ITaskTagConstants {
    public static final String ID_TASK_TAGS = "TaskTags.List";
    public static final String ID_IGNORE_CASE = "TaskTags.IgnoreCase";
    public static final String ID_WHITESPACE = "TaskTags.AllowWhiteSpace";

}